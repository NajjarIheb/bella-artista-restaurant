<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
        'endpoint' => env('MAILGUN_ENDPOINT', 'api.mailgun.net'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'flouci' => [
        'public_key' => env('FLOUCI_PUBLIC_KEY'),
        'private_key' => env('FLOUCI_PRIVATE_KEY'),
        'base_url' => env('FLOUCI_BASE_URL', 'https://developers.flouci.com/api/v2'),
        'test_mode' => env('FLOUCI_TEST_MODE', true),
    ],

    'google' => [
        'client_id' => env('GOOGLE_CLIENT_ID'),
        'configured' => env('GOOGLE_CLIENT_ID'),
        'site_verification' => env('GOOGLE_SITE_VERIFICATION'),
    ],

];
